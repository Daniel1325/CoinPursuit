package defaultpackage;

public class Player {
	public static int m_x, m_y, m_score;
	public static String m_ipAddress;
	
	public Player(int x, int y, String ipAddress, int score) {
		m_x = x;
		m_y = y;
		m_score = score;
		m_ipAddress = ipAddress;
	}
	
	public static String getIp() {
		return m_ipAddress;
	}
	
	public static boolean movePlayer(int x, int y) {
		//check if player has moved one space only
		m_x = x;
		m_y = y;
		return true;
	}
	
}

package defaultpackage;

import java.util.ArrayList;

public class World {
	public static boolean m_isEmpty;
	public static int m_numOfPlayers, m_universeX, m_universeY;
	public static ArrayList<Player> m_players;
	public static String m_hostIP;
	
	
	public World() {
		
	}
	
	public static boolean getIsEmpty() {
		return m_isEmpty;
	}
	
	public static void setIsEmpty(boolean isEmpty) {
		m_isEmpty = isEmpty;
	}
	
	public static int getNumOfPlayers() {
		return m_numOfPlayers;
	}
	
	public static void setNumberOfPlayers(int numOfPlayers) {
		m_numOfPlayers = numOfPlayers;
	}
	
	public static int getUniverseX() {
		return m_universeX;
	}
	
	public static int getUniverseY() {
		return m_universeY;
	}
	
	public static String getHostIPAddress() {
		return m_hostIP;
	}
	
	public static void addPlayer(String ipAddress, int playerX, int playerY, int score) {
		m_players.add(new Player(playerX, playerY, ipAddress, score));
	}
		
}
